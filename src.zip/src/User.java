public class User {
    public String school_mail;
    public String name;
    public String surname;
    public String p_id;
    public String passw;
}
