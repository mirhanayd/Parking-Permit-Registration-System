import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class registirationf extends JDialog{
    private JTextField school_email;
    private JTextField passport_number;
    private JTextField first_name;
    private JTextField last_name;
    private JPasswordField password;
    private JButton registerButton;
    private JButton cancelButton;
    private JPanel RegisterPanel;

    public registirationf(JFrame parent){
        super(parent);
        setTitle("Create a new registration");
        setContentPane(RegisterPanel);
        setModal(true);
        setMinimumSize(new Dimension(820,600));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                registerUser();
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                dispose();
            }
        });
        setVisible(true);

    }

    private void registerUser() {
        String school_mail = school_email.getText();
        String name = first_name.getText();
        String surname = last_name.getText();
        String p_id = passport_number.getText();
        String passw = String.valueOf(password.getPassword());

        if (school_mail.isEmpty() || name.isEmpty() || surname.isEmpty() || p_id.isEmpty() || passw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all the fields",
                    "Try Again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        user = addUSerToDatabase(school_mail, name, surname, p_id, passw);
        if (user != null) {
            dispose();
        }
        else{
            JOptionPane.showMessageDialog(this,
                    "Failed to register new user",
                    "Try Again",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    public User user;
    private User addUSerToDatabase(String school_mail, String name, String surname, String p_id, String passw) {
        User user = null;
        final String DB_URL = "jdbc:mysql://127.0.0.1:3306/parking_permit?serverTimezone=UTC";
        final String USER = "root";
        final String PASS = "986532";
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

            String sql = "INSERT INTO `parking_permit`.`users`(school_mail, name, surname, p_id, passw)" +
                    "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, school_mail);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, surname);
            preparedStatement.setString(4, p_id);
            preparedStatement.setString(5, passw);

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                user = new User();
                user.school_mail = school_mail;
                user.name = name;
                user.surname = surname;
                user.p_id = p_id;
                user.passw = passw;
            }
            preparedStatement.close();
            conn.close();
        }catch (Exception e){
            e.printStackTrace();
        }

        return user;

    }

    public static void main(String[] args){
        registirationf myForm = new registirationf(null);

        User user = myForm.user;
        if (user != null) {
            System.out.println("Succesful registration.");
        }
        else{
            System.out.println("Failed to registration.");
        }
    }
}
