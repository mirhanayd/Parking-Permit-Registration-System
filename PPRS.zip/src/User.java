public class User {
    public String id;
    public String name;
    public String surname;
    public String p_id;
    public String passw;
}
